package com.crm.test;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.paytmcrm.base.TestBase;
import com.paytmcrm.pages.HomePage;
import com.paytmcrm.pages.Paytm_LoginPage;
import com.paytmcrm.pages.Units_and_Users_Page;
import com.paytmcrm.util.TestUtil;
public class Unit_UserPage_Test extends TestBase{
	Paytm_LoginPage lp;
	HomePage hm;
	WebDriver driver;
//	Logger log = Logger.getLogger(Unit_UserPage_Test.class);
	Units_and_Users_Page up;
	
	
	Unit_UserPage_Test(){
		PageFactory.initElements(driver, this);
	}
	
	
	@Test(priority=1)
	public void loginpagetest() {
//		log.info("****************************** Starting test cases execution  *****************************************");
		initialization();
		 lp = new Paytm_LoginPage();
		 hm =lp.validateLogin(prop.getProperty("Username"), prop.getProperty("password"));
		 driver.manage().timeouts().pageLoadTimeout(TestUtil.PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
		 driver.manage().timeouts().implicitlyWait(TestUtil.IMPLICIT_WAIT, TimeUnit.SECONDS);
		 
		 
		}
//	@Test(priority=2)
//	public void homepage_data_Edit() {
//		up = new Units_and_Users_Page();
//		 up.unitslistpage();
//		 up.Edit();
//		 up.reset();
//		
//		
//	}
	
	
	@Test(priority=2)
	public void homepage_data_Create() throws IOException {
//		log.info("****************************** starting test case *****************************************");
//		log.info("****************************** homepage_data_Test *****************************************");
		 up = new Units_and_Users_Page();
		 up.unitslistpage();
		 up.Addunitform();
		 up.first_lastname("nilesh", "sharma");
		 up.select_block(1);
		 up.enter_city("kolkata");
		 up.enter_unit("4");
		 up.isd_code("+91");
		 up.phonenum("124512455");
		 up.intercom("254");
		 up.enter_email("nileshverma@yahoo.com");
		
		 up.select_tenant(2);
		 up.dob();
		 up.tenant_cateory(1);
		 up.verification("alpha");
		 
		 up.primary_num("8778455485");
		 up.occupation("Engineer");
		 up.highest_education("B.E");
		 up.submit();
		 driver.close();
		 
//		String[] s= {"123","str"};
//		 for (int i = 0; i < s.length; i++) {
//		
//		}
	 }
	
}
