package com.crm.test;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.paytmcrm.base.TestBase;
import com.paytmcrm.pages.HomePage;
import com.paytmcrm.pages.Paytm_LoginPage;


public class Paytm_LoginPageTest extends TestBase {

	Paytm_LoginPage lp;
	HomePage hm;
	
		public Paytm_LoginPageTest() {
			super();
				}
	
		@BeforeClass
		public void SetUp() {
			
			initialization();
			 lp = new Paytm_LoginPage();
			   
		}
		
		@Test(priority=1)
		public void loginpagetitle() throws IOException {
	
			initialization();
			 lp = new Paytm_LoginPage();
		String title =lp.getpageTitile();
		Assert.assertEquals(title, "Apartment Login");
		System.out.println(title);
			
		}
		@Test(priority=2)
		public void loginpagetest() {
			
		hm =lp.validateLogin(prop.getProperty("Username"), prop.getProperty("password"));
		
			
		}
		@AfterClass
		public void TeardownDown() {
			driver.close();
		}
		
	}
