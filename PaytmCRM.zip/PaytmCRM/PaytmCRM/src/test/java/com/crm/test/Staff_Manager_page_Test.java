package com.crm.test;



import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;
import org.testng.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.paytmcrm.base.TestBase;
import com.paytmcrm.pages.HomePage;
import com.paytmcrm.pages.Paytm_LoginPage;
import com.paytmcrm.pages.Staff_Manager_Page;
import com.paytmcrm.util.TestUtil;

public class Staff_Manager_page_Test extends TestBase {
	
	Paytm_LoginPage lp;
	HomePage hm;
	Staff_Manager_Page sm;
	
	Staff_Manager_page_Test(){
		PageFactory.initElements(driver, this);
	}
//	@Test(priority =1)
	@BeforeClass
	public void loginpagetest() {
		initialization();
		 lp = new Paytm_LoginPage();
		 hm =lp.validateLogin(prop.getProperty("Username"), prop.getProperty("password"));
		 driver.manage().timeouts().pageLoadTimeout(TestUtil.PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
		 driver.manage().timeouts().implicitlyWait(TestUtil.IMPLICIT_WAIT, TimeUnit.SECONDS);
		
	}
	@BeforeMethod
	public void staff_manager_page_validate() throws InterruptedException {
		sm = new Staff_Manager_Page();
		sm.Staff_Manager();
		sm.Apartment_Staff_sidebar();
//		sm.Create_staff_user();
		 Thread.sleep(5000);
	}
	@Test(priority =1)
	public void staff_manager_page_Create() throws InterruptedException {
		for (int i = 0; i < 10; i++) {
			sm.Create_staff_user();
			sm.firstname("jyoti");
			String[] s1= {"123","ajay","arun"};
			int count =1;
			for(int j=0;j<s1.length;j++) {
			
			sm.lastname(s1[j]);
			count++;
			System.out.println(s1[j]);
			System.out.println("index of inputs are :" + j);
			Thread.sleep(5000);
			sm.lastname_clear();
			Thread.sleep(5000);
			
			}
//			sm.lastname("s");
			sm.email("jyoti@xiphiastec.com");
			sm.phone("7454545454");
			sm.role(2);
//			sm.set_password("jyoti@xiphiastec.com");
			sm.chk_box();
			String s =sm.show_password();
			System.out.println(s);
			sm.submit();
			String expected_Text = "Staff userts details Created";
			 String actualString = driver.findElement(By.className("toast-message")).getText();
			 Assert.assertEquals(actualString,(expected_Text));
			driver.manage().timeouts().implicitlyWait(TestUtil.IMPLICIT_WAIT, TimeUnit.SECONDS);
			Thread.sleep(5000);
		}
		
	}@Test(priority =2)
	public void staff_manager_page_Edit() throws InterruptedException {
		for (int i = 0; i < 10; i++) {
			
		
		sm.Edit_button_click();
		sm.firstname_clear();
		sm.firstname("jyoti");
		sm.lastname_clear();
		String[] s1= {"tttt","ajay","arun"};

		for(int j=0;j<s1.length;j++) {
		
		sm.lastname(s1[j]);
		}
		
		sm.email_clear();
		sm.email("jyoti@xiphiastec.com");
		sm.phone_clear();
		sm.phone("7454545454");
//		sm.role(3);
		sm.set_password_clear();
//		sm.set_password("jyoti@xiphiastec.com");
		sm.chk_box();
		String s =sm.show_password();
		System.out.println(s);
//		sm.submit();
		 driver.manage().timeouts().implicitlyWait(TestUtil.IMPLICIT_WAIT, TimeUnit.SECONDS);
		 Thread.sleep(5000);
		 String expected_Text ="Staff userts details Updated";
		 WebElement actualString = driver.findElement(By.className("toast-message"));
		 actualString.getText();
		 Assert.assertTrue(actualString.equals(expected_Text));
		} 
	}@Test(priority =3)
	public void staff_manager_page_delete() throws InterruptedException {
		staff_manager_page_validate();
		for (int i = 0; i < 10; i++) {
			sm.Delete();
			driver.findElement(By.linkText("Yes")).click();
			Thread.sleep(2000);
			String expected_Text = "Staff userts details Deleted";
			 String actualString = driver.findElement(By.className("toast-message")).getText();
			 assertTrue(actualString.equals(expected_Text));
		}
		
	}

}
