package com.paytmcrm.util;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.paytmcrm.base.TestBase;

public class TestUtil extends TestBase{

	static Workbook book;
	static Sheet sheet;
	static JavascriptExecutor js; 
	public static long PAGE_LOAD_TIMEOUT =60;
	public static long IMPLICIT_WAIT =30;
	
	public static void takeScreenshotAtEndOfTest(WebDriver driver,String screenshotName) throws IOException {
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		  Date date = new Date() ;
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss") ;
		System.getProperty("user.dir");
		try {
			FileUtils.copyFile(scrFile,new File("./CRM/get "+" "+screenshotName+ " "+dateFormat.format(date)+".png"));
		} catch (IOException e) {
			System.out.println("Exception while taking Screenshot");
		}
	}
}

