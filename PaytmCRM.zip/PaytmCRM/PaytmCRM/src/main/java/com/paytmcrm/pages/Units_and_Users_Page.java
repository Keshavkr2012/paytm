package com.paytmcrm.pages;

import java.time.LocalDate;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.paytmcrm.base.TestBase;
import com.paytmcrm.util.TestUtil;

public class Units_and_Users_Page extends TestBase {

	
	@FindBy(xpath="//*[@id=\'app\']/aside/div/section/ul/li[3]/a/span")
	WebElement Units_Users;

	@FindBy(linkText = "Approved Users")
	WebElement ApproedUsers;
	
	@FindBy(linkText="Add Approved User")
	WebElement adduser;
	
	@FindBy(name="First_Name")
	WebElement firstname;
	
	@FindBy(name="Last_Name")
	WebElement lastname;
	
	@FindBy(id="BlockId")
	WebElement 	 select_block;

	@FindBy(name="city")
	WebElement 	 cityname;
	
	@FindBy(name ="UnitNO")
	WebElement unitno;
	
	@FindBy(name ="Phone_No")
	WebElement phonenum;
	
	@FindBy(name = "Intercom")
	WebElement intercom;
	
	@FindBy(name = "EmailAddress")
	WebElement email;
	
	@FindBy(name = "ownership")
	WebElement ownership;
	
	@FindBy(name = "TenantType")
	WebElement select_tenanttype;
	
	@FindBy(name = "TenantCategory")
	WebElement tenant_Category;
	
	@FindBy(name = "DateOfBirth")
	WebElement dob;
	
	@FindBy(name = "primarycontact")
	WebElement primary_num;
	
	@FindBy(name = "Occupation")
	WebElement occupation;
	
	@FindBy(name = "Education")
	WebElement highest_education;
	
	@FindBy(name = "verification")
	WebElement verification_text;
	
	@FindBy(xpath = "//*[@id=\'v-pills-tabContent\']/div/div/div/div[2]/div/form/div[2]/button[2]")
	WebElement submit;
	//.//span[@class="autoSuggKeywords"]
	//"css=a[href*='#myModal'][id='736 13']"

	@FindBy(name="ISD_Code")
	WebElement 	 isd_code;
	
	@FindBy(linkText ="Back to List")
	WebElement 	 backtolist;
	
	@FindBy(xpath ="//*[@id=\'example\']/tbody/tr[1]/td[6]/table/tbody/tr/td/p/a[2]/i")
	WebElement 	 edit;
	
	@FindBy(xpath ="//button[contains(.,'Reset')]")
	WebElement 	 reset;
	
	
		public Units_and_Users_Page() {
		
		PageFactory.initElements(driver, this);
		
		}
		public void unitslistpage() {
			Units_Users.click();
			ApproedUsers.click();
			
		}
		public void Addunitform() {
			
			driver.manage().timeouts().implicitlyWait(TestUtil.IMPLICIT_WAIT, TimeUnit.SECONDS);
			adduser.click();
			
		}public void first_lastname(String s,String t){
			firstname.sendKeys(s);
			lastname.sendKeys(t);
		}public void select_block(int i) {
			Select sl = new Select(select_block);
			sl.selectByIndex(i);
		}public void enter_city(String s) {
			cityname.sendKeys(s);
		}public void enter_unit(String s) {
			unitno.sendKeys(s);
		}public void isd_code(String s) {
			isd_code.sendKeys(s);
		}public void primary_num(String s) {
			primary_num.sendKeys(s);
		}public void intercom(String s) {
			intercom.sendKeys(s);
		}public void enter_email(String s) {
			email.sendKeys(s);
		}public void select_tenant(int i) {
			 driver.manage().timeouts().implicitlyWait(TestUtil.IMPLICIT_WAIT, TimeUnit.SECONDS);
			Select sel = new Select(select_tenanttype);
			sel.selectByIndex(i);
		}public void highest_education(String s) {
			highest_education.sendKeys(s);
		}
//			ownership.sendKeys(s);
		public void phonenum(String s) {
			phonenum.sendKeys(s);
		}public void occupation(String s) {
			occupation.sendKeys(s);
		}
		public void verification(String s) {
			verification_text.sendKeys(s);
		}
		public void tenant_cateory(int i) {
			 driver.manage().timeouts().implicitlyWait(TestUtil.IMPLICIT_WAIT, TimeUnit.SECONDS);
			Select sel = new Select(tenant_Category);
			sel.selectByIndex(i);;
		}
		
		public void dob() {
			LocalDate myDate =LocalDate.parse("2014-02-14");
			
			dob.sendKeys("myDate");
		}
		
		public void submit() {
			dob.click();
		}
		public void Edit() {
			edit.click();
		}
		public void reset() {
			reset.click();
		}
		
}

