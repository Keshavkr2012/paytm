package com.paytmcrm.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.paytmcrm.base.TestBase;

public class Paytm_LoginPage extends TestBase{

	
	///Object Repository
	@FindBy(name="UserName")
	WebElement UserName;

	@FindBy(name="Password")
	WebElement password;

	@FindBy(xpath="//input[@type='submit']")
	WebElement loginbutton;
	
//	@FindBy(xpath="//img[@class,'/xiphiascrm/Content/images/xiphias_logonew.png']")
//	WebElement pageImage;
	
	public Paytm_LoginPage() {
		
		PageFactory.initElements(driver, this);
		
	}
	public HomePage validateLogin(String un,String psw) {
		UserName.sendKeys(un);
		password.sendKeys(psw);
		loginbutton.click();
		return new HomePage();
	}
	
	public  String getpageTitile() {
		return driver.getTitle();
		
	}
}

