package com.paytmcrm.pages;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.paytmcrm.base.TestBase;
import com.paytmcrm.util.TestUtil;

public class Staff_Manager_Page extends TestBase {

//	WebDriver driver;
		public Staff_Manager_Page() {
		
		PageFactory.initElements(driver, this);
		
		}

	
	@FindBy(linkText = "Staff Manager")
	WebElement Staff_Manager;
	
	
	@FindBy(linkText="Apartment Staff")
	WebElement Apartment_Staff_sidebar;
	
	@FindBy(linkText="Create staff user")
	WebElement Create_staff_user;
	
	@FindBy(name="apartmentStaffUserClass.F_NAME_S")
	WebElement firstname;
	
	@FindBy(name="apartmentStaffUserClass.L_NAME_S")
	WebElement lastname;
	
	@FindBy(xpath="//*[@id=\'example\']/tbody/tr[1]/td[5]/a[1]")
	WebElement Edit_button_click;
	
	@FindBy(name="apartmentStaffUserClass.ASU_EMAILID")
	WebElement email;
	
	@FindBy(name="apartmentStaffUserClass.PHONE_S")
	WebElement phone;
	
	@FindBy(name="apartmentStaffUserClass.ASU_ROLE_ROLEID")
	WebElement role;
	
	@FindBy(name="apartmentStaffUserClass.ASU_PASSWORD")
	WebElement 	 set_password;
	
	@FindBy(xpath="//input[@type='checkbox']")
	WebElement 	 chk_box;
	
	@FindBy(xpath="//*[@id=\'v-pills-tabContent\']/div/div/div/div/div[3]/button[2]")
	WebElement 	 submit_button;
	
	@FindBy(xpath="//*[@id=\'example\']/tbody/tr[1]/td[5]/a[2]")
	WebElement 	 Delete;
	////*[@id="example"]/tbody/tr[1]/td[5]/a[2]
	
	// for message :/html/head/link[7]
	@FindBy(xpath="/html/head/link[7]")
	WebElement 	 get_message;
	
	
	
	public void Delete(){
		Delete.click();
		
	}
	public void email(String s){
		email.sendKeys(s);
		
	}
	public void role(int i) {
		Select sl = new Select(role);
		sl.selectByIndex(i);
	}
	public void Staff_Manager() {
//		 driver.manage().timeouts().implicitlyWait(TestUtil.IMPLICIT_WAIT, TimeUnit.SECONDS);
		Staff_Manager.click();
	}
	public void Apartment_Staff_sidebar() {
		Apartment_Staff_sidebar.click();;
	}
	public void Create_staff_user() {
		Create_staff_user.click();
	}
	public void firstname(String s) {
		firstname.sendKeys(s);
	}
	public void lastname(String s) {
		lastname.sendKeys(s);
	}
	public void phone(String s) {
		phone.sendKeys(s);
	}
	public void set_password(String s) {
		set_password.sendKeys(s);
	}
	public void set_password_clear() {
		set_password.sendKeys();
	}
	public void chk_box() {
		chk_box.click();
	}
	public void submit() {
		submit_button.click();
	}
	public String show_password() {
		String s=set_password.getText();
		System.out.println(s);	
		return s;
	}
	public void email_clear(){
		email.clear();
		
	}
	public void role_edit(int i) {
		Select sl = new Select(role);
		sl.selectByIndex(i);
	}


	
	public void firstname_clear() {
		firstname.clear();
	}
	public void lastname_clear() {
		lastname.clear();
	}
	public void phone_clear() {
		phone.sendKeys();
	}
	public void clear_password() {
		set_password.clear();
	}
	public void Edit_button_click() {
		Edit_button_click.click();
	}
	public void get_message(){
		get_message.click();
		
	}

	
	
	
	
}
